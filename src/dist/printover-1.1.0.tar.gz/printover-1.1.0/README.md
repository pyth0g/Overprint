# Overprint

A package that makes it easy to print to the same line again.